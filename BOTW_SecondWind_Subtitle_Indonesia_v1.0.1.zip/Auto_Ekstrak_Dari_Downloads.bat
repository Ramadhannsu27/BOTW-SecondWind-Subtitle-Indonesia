@echo off
chcp 65001 >nul
title Ekstraktor Otomatis Mod Bahasa Indonesia BOTW

echo ===================================================================
echo   EKSTRAKTOR OTOMATIS MOD TERJEMAHAN DARI FOLDER DOWNLOADS
echo ===================================================================
echo.
echo Mencari file zip mod terjemahan di folder Downloads Anda...
echo.

set "DEST_MSG=%~dp0content\Msg"
set "USER_DL=%USERPROFILE%\Downloads"

powershell -NoProfile -ExecutionPolicy Bypass -Command "& {
    $dl = [System.Environment]::GetFolderPath('UserProfile') + '\Downloads';
    $dest = '%DEST_MSG%';
    $zipFiles = Get-ChildItem -Path $dl -Filter '*.zip' | Where-Object { $_.Name -like '*Zelda*' -or $_.Name -like '*Translate*' -or $_.Name -like '*Indo*' } | Sort-Object LastWriteTime -Descending;
    if ($zipFiles.Count -eq 0) {
        # Ambil file zip terbaru apapun jika tidak ditemukan nama spesifik
        $zipFiles = Get-ChildItem -Path $dl -Filter '*.zip' | Sort-Object LastWriteTime -Descending | Select-Object -First 3;
    }
    if ($zipFiles.Count -eq 0) {
        Write-Host '[PERINGATAN] Tidak ditemukan file .zip di folder Downloads!' -ForegroundColor Yellow;
        Write-Host 'Pastikan Anda sudah mengklik download file mod di browser Anda.' -ForegroundColor Yellow;
        exit 1;
    }
    Write-Host 'Ditemukan file arsip:' $zipFiles[0].FullName -ForegroundColor Cyan;
    Write-Host 'Mengekstrak file pesan Msg_USen.product.sarc...' -ForegroundColor Cyan;
    
    $tempDir = Join-Path $env:TEMP ('botw_extract_' + (Get-Random));
    Expand-Archive -LiteralPath $zipFiles[0].FullName -DestinationPath $tempDir -Force;
    
    $sarcFiles = Get-ChildItem -Path $tempDir -Filter '*Msg_*.product.sarc' -Recurse;
    if ($sarcFiles.Count -eq 0) {
        Write-Host '[INFO] Mencari semua file sarc di dalam arsip...' -ForegroundColor Yellow;
        $sarcFiles = Get-ChildItem -Path $tempDir -Filter '*.sarc' -Recurse;
    }
    
    if ($sarcFiles.Count -gt 0) {
        New-Item -ItemType Directory -Path $dest -Force | Out-Null;
        foreach ($file in $sarcFiles) {
            Copy-Item -Path $file.FullName -Destination $dest -Force;
            Write-Host ('[BERHASIL] File disalin: ' + $file.Name) -ForegroundColor Green;
        }
        Remove-Item -Path $tempDir -Recurse -Force -ErrorAction SilentlyContinue;
        Write-Host 'Selesai! File terjemahan sudah siap di folder mod Anda.' -ForegroundColor Green;
    } else {
        Write-Host '[ERROR] File Msg_USen.product.sarc tidak ditemukan di dalam zip tersebut!' -ForegroundColor Red;
        Remove-Item -Path $tempDir -Recurse -Force -ErrorAction SilentlyContinue;
        exit 1;
    }
}"

echo.
echo ===================================================================
pause
